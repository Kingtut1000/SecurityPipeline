import json
import boto3
import gzip
import os
import time
import uuid
from io import BytesIO

# Initialize AWS services
s3 = boto3.client('s3')
sns = boto3.client('sns')
dynamodb = boto3.resource('dynamodb')

# Get environment variables
SNS_TOPIC_ARN = os.environ.get('SNS_TOPIC_ARN')
DYNAMODB_TABLE = os.environ.get('DYNAMODB_TABLE')
LOG_LEVEL = os.environ.get('LOG_LEVEL', 'INFO')
MONITORED_EVENTS_PATH = os.environ.get('MONITORED_EVENTS_PATH', 'monitored_events.json')

# Load monitored events
try:
    with open(MONITORED_EVENTS_PATH, 'r') as file:
        events_data = json.load(file)
        monitored_events = events_data.get('monitoredEvents', [])
    print(f"Loaded {len(monitored_events)} monitored events")
except Exception as e:
    print(f"Error loading monitored events: {str(e)}")
    monitored_events = []

def lambda_handler(event, context):
    """Main Lambda handler function"""
    print(f"Processing SQS event: {json.dumps(event)}")
    
    try:
        # Process each SQS message (S3 event notification)
        for record in event.get('Records', []):
            body = json.loads(record.get('body', '{}'))
            
            # Process each S3 event
            for s3_record in body.get('Records', []):
                if s3_record.get('eventSource') == 'aws:s3' and s3_record.get('eventName', '').startswith('ObjectCreated:'):
                    bucket = s3_record.get('s3', {}).get('bucket', {}).get('name')
                    key = s3_record.get('s3', {}).get('object', {}).get('key')
                    if bucket and key:
                        process_s3_object(bucket, key)
        
        return {
            'statusCode': 200,
            'body': 'Processing complete'
        }
    except Exception as e:
        print(f"Error processing events: {str(e)}")
        raise

def process_s3_object(bucket, key):
    """Process an S3 object (CloudTrail log file)"""
    print(f"Processing S3 object: s3://{bucket}/{key}")
    
    try:
        # Get the object from S3
        response = s3.get_object(Bucket=bucket, Key=key)
        
        # Decompress the gzipped content
        with gzip.GzipFile(fileobj=BytesIO(response['Body'].read())) as gzipfile:
            content = gzipfile.read()
        
        cloudtrail_log = json.loads(content)
        
        # Process CloudTrail records
        if 'Records' in cloudtrail_log and isinstance(cloudtrail_log['Records'], list):
            print(f"Processing {len(cloudtrail_log['Records'])} CloudTrail records")
            
            for record in cloudtrail_log['Records']:
                process_cloudtrail_record(record)
    except Exception as e:
        print(f"Error processing S3 object s3://{bucket}/{key}: {str(e)}")
        raise

def process_cloudtrail_record(record):
    """Process a single CloudTrail record"""
    if LOG_LEVEL == 'DEBUG':
        print(f"Processing CloudTrail record: {json.dumps(record)}")
    
    try:
        # Check if the event is in our monitored events list
        event_name = record.get('eventName')
        if event_name in monitored_events:
            print(f"Monitored event detected: {event_name}")
            handle_security_event(record)
    except Exception as e:
        print(f"Error processing CloudTrail record: {str(e)}")
        raise

def handle_security_event(record):
    """Handle a monitored security event"""
    print(f"Security event detected: {record.get('eventName')}")
    
    try:
        # Create a unique event ID
        event_id = f"{record.get('eventID', generate_id())}-{int(time.time())}"
        
        # Prepare event details
        event_details = {
            'EventId': event_id,
            'Timestamp': record.get('eventTime', datetime_now_iso()),
            'EventName': record.get('eventName'),
            'EventSource': record.get('eventSource'),
            'Region': record.get('awsRegion'),
            'SourceIpAddress': record.get('sourceIPAddress'),
            'UserIdentity': json.dumps(record.get('userIdentity')) if record.get('userIdentity') else None,
            'Resources': json.dumps(record.get('resources')) if record.get('resources') else None,
            'Severity': 'HIGH',  # All monitored events are considered high severity
            'RawEvent': json.dumps(record),
            'ExpirationTime': int(time.time()) + (90 * 24 * 60 * 60)  # 90 days TTL
        }
        
        # Store event in DynamoDB
        table = dynamodb.Table(DYNAMODB_TABLE)
        table.put_item(Item=event_details)
        
        # Send alert to SNS
        user_identity_str = json.dumps(record.get('userIdentity', {}), indent=2) if record.get('userIdentity') else 'N/A'
        resources_str = json.dumps(record.get('resources', {}), indent=2) if record.get('resources') else 'N/A'
        
        message = f"""
Security Event Detected

Event ID: {event_id}
Time: {event_details['Timestamp']}
Event: {event_details['EventName']}
Source: {event_details['EventSource']}
Region: {event_details['Region']}
IP Address: {event_details['SourceIpAddress']}
Severity: HIGH

User: {user_identity_str}

Resources: {resources_str}
        """
        
        sns.publish(
            TopicArn=SNS_TOPIC_ARN,
            Subject=f"Security Alert: {record.get('eventName')}",
            Message=message
        )
        
        print(f"Alert sent for event {event_id}")
    except Exception as e:
        print(f"Error handling security event: {str(e)}")
        raise

def generate_id():
    """Generate a random ID"""
    return str(uuid.uuid4())

def datetime_now_iso():
    """Get current datetime in ISO format"""
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
